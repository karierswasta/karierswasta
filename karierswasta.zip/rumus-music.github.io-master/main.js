import { startEditorApp } from './src/EditorApp.js';

startEditorApp();